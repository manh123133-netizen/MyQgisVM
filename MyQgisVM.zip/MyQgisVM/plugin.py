# -*- coding: utf-8 -*-
# MyQgisVM Plugin — protected distribution
import importlib.util as _util, os as _os
_pyc  = _os.path.join(_os.path.dirname(__file__), 'plugin.pyc')
_spec = _util.spec_from_file_location('plugin', _pyc)
_mod  = _util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)
classFactory = _mod.classFactory
