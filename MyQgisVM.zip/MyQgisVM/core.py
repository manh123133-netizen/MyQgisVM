# -*- coding: utf-8 -*-
# MyQgisVM Plugin — protected distribution
import importlib.util as _util, os as _os, sys as _sys
_pyc  = _os.path.join(_os.path.dirname(__file__), 'core.pyc')
_spec = _util.spec_from_file_location('MyQgisVM.core', _pyc)
_mod  = _util.module_from_spec(_spec)
_sys.modules['MyQgisVM.core'] = _mod
_spec.loader.exec_module(_mod)
from MyQgisVM.core import *
