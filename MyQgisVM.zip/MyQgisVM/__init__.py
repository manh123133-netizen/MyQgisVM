# -*- coding: utf-8 -*-
# MyQgisVM Plugin — protected distribution
# Do not modify this file.
import importlib.util as _util, os as _os
_pyc = _os.path.join(_os.path.dirname(__file__), '__init__.pyc')
_spec = _util.spec_from_file_location('__init__', _pyc)
_mod  = _util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)
from __init__ import *
try:
    from __init__ import classFactory
except ImportError:
    pass
